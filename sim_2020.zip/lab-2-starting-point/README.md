# Lab 2 Starting Point

A Pen created on CodePen.io. Original URL: [https://codepen.io/cici541/pen/xxJXdvO](https://codepen.io/cici541/pen/xxJXdvO).

